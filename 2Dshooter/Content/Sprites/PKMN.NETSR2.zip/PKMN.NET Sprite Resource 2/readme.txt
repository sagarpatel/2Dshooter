PKMN.NET SPRITE RESOURCE DOWNLOAD v2.0.0

This collection of sprites from the official Pok�mon RPG games has been compiled by Typhlosion for PKMN.NET, with coding help from Joeno. A lot of it actually. Thanks to Kay, Liam and The Doctor for help in organising these sprites.

These sprites do not belong to PKMN.NET and are � Nintendo. You are free to use these sprites where you wish and to distribute them without permission or credit. Although credit is always nice. So is money. Or if all else fails, chocolate. Actually, alcohol works as well. But only if you're above 18.

The initial design of the Sprite Resource on the site ensured a number of repetitions - I have tried to remove this as much as possible, to reduce the size of this download. Remembering there are thousands of sprites, there will probably be some mistakes somewhere. If you find any, please report them via the forums or by contacting me at admin@pkmn.net.

The DPPt sprites have been moved around a little this time. Well, I've attempted to. It'll be wrong somewhere, sods law. You can now find male sprites, genderless sprites and sprites without gender differences in the Male folders. Any sprites specifically different for females will be found... yes, in the female folders. Well done you.

Sprite Resource v3 is likely to be released in 2010 and will likely include sprites from HeartGold and SoulSilver, as well as trainer sprites and berries if you're lucky. Oh and a further reshuffle of the structure. Any further requests should be made on the forums or by emailling me at admin@pkmn.net.

VERSION HISTORY

v2.0.1 Fixed Platinum sprites omissions as reported by Chaos Rush in the forums.
v2.0.0 Restructured sprites to remove some repetition. Included all sprites from Platinum, Mystery Dungeon, Mystery Dungeon 2 and Trozei.
v1.1.0 Included some sprites from Mystery Dungeon 2, Pinball, Pinball R/S and Platinum.
v1.0.0 Included all major sprites for all 4 generations of RPG.
